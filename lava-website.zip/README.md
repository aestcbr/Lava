# Website Lava 🌋

Project website sederhana bertema lava dan gunung berapi.

## Fitur
- Halaman utama
- Galeri sederhana
- Tema warna panas (lava)

## Cara Menjalankan
Buka file `index.html` di browser.
